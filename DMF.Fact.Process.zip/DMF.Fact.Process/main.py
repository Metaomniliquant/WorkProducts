import api.sec as sec


sec.schedule_task()
sec.run()
