from sys import executable
import api.time as time
from api.config import app as config
import api.models as models
import api.schedule as schedule
import api.logger as api_logger

log = api_logger.log
logc = api_logger.logc
start = api_logger.enter
error = api_logger.error


start()
log(executable)


def run():
    log('Running')
    logc(config.run_section)

    while True:
        schedule.run_or_exit(
            int(config.get('max_wait_between_attempts'), base=10))


def schedule_task():
    try:
        log('Scheduling task')
        headers = get_headers()
        scheduleModel = models.ScheduleModel()
        job = schedule.get_minute_job(scheduleModel.minutes)
        out_file_suffix = f"{time.date_time_file_name()}{scheduleModel.expected_extension}"
        submission_file_path = f"{scheduleModel.submission_out_file}/{out_file_suffix}"
        fact_file_path = f"{scheduleModel.fact_out_file}/{out_file_suffix}"
        schedule.schedule_task(
            job,
            submission_file_path,
            fact_file_path,
            headers,
            scheduleModel
        )
    except Exception as ex:
        error(ex)


def get_headers():
    log('Retrieving headers')
    if not config.is_debug():
        headers = {
            'User-Agent': f"{config.get('user_agent_first_name')} {config.get('user_agent_last_name')} {config.get('user_agent_email')}",
        }
    else:
        headers = 0

    logc(headers)
    return headers
