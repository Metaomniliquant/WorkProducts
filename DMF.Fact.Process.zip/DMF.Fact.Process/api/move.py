import shutil


def move_file(source, destination_path):
    shutil.move(source, destination_path)
