import shutil
import api.path as path


def try_unzip(zip_file):
    ext = path.get_ext(zip_file)
    if ext == '.zip':
        extract_dir = path.get_dir_from_file(zip_file)
        shutil.unpack_archive(zip_file, extract_dir)
        return extract_dir
    return ''
