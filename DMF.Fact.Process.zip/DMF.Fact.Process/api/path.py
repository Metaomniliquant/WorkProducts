import os
import pathlib


def get_ext(local_file):
    return pathlib.Path(local_file).suffix


def get_dir_from_file(local_file):
    filename, file_extension = os.path.splitext(local_file)
    return filename


def get_files(dir, target_file_extension):
    results = []
    with os.scandir(dir) as it:
        for entry in it:
            if entry.is_file() and entry.name.endswith(target_file_extension):
                results.append(entry.name)
    return results
