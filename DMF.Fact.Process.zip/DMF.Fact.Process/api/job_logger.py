from api.config import app as config
from api.mongo import db
from api import time


ENTER_MESSAGE = 1
EXIT_MESSAGE = 2

INFO_MESSAGE = 10
ERROR_MESSAGE = 90

SORT = db.DESCENDING
MESSAGE_KEY = 'message'
TYPE_KEY = 'type'
ENTER_KEY = 'ENTER'
EXIT_KEY = 'EXIT'

INFO_KEY = 'INFO'
ERROR_KEY = 'ERROR'


class JobLogger:
    def __init__(self, target_db, target_collection, target_job_collection) -> None:
        self.collection = db.collection(target_db, target_collection)
        self.jobs = db.collection(target_db, target_job_collection)
        db.index(self.collection, [(MESSAGE_KEY, db.TEXT)],
                 f'{target_collection}_message_textindex')
        db.index(self.collection, [(TYPE_KEY, SORT)],
                 f'{target_collection}_type_index')
        self.job_result = self.jobs.insert_one(
            {"start_date": None, "end_date": None})

    def get_job_id(self):
        return self.job_result.inserted_id

    def info(self, message):
        doc = {
            'job_id': self.job_result.inserted_id,
            'time': time.time_to_string(),
            'type': INFO_MESSAGE,
            'message': f'{INFO_KEY} | {message}'
        }
        print(doc)
        self.collection.insert_one(doc)

    def error(self, message):
        doc = {
            'job_id': self.job_result.inserted_id,
            'time': time.time_to_string(),
            'type': ERROR_MESSAGE,
            'message': f'{ERROR_KEY} | {message}'
        }
        print(doc)
        self.collection.insert_one(doc)

    def enter(self):
        doc = {
            'job_id': self.job_result.inserted_id,
            'time': time.time_to_string(),
            'type': ENTER_MESSAGE,
            'message': f'{ENTER_KEY} | Starting'
        }
        print(doc)
        self.collection.insert_one(doc)
        self.jobs.update_one(
            {'_id': self.job_result.inserted_id},
            {'$set': {'start_date': time.time_to_string()}})

    def end(self):
        doc = {
            'job_id': self.job_result.inserted_id,
            'time': time.time_to_string(),
            'type': EXIT_MESSAGE,
            'message': f'{EXIT_KEY} | Exiting'
        }
        print(doc)
        self.collection.insert_one(doc)
        self.jobs.update_one({'_id': self.job_result.inserted_id},
                             {'$set': {'end_date': time.time_to_string()}})


logger = JobLogger(config.get('target_db'),
                   config.get('target_log_collection'),
                   config.get('target_job_collection'))
