from api.job_logger import logger


def job_id():
    return logger.get_job_id()


def log(message):
    logger.info(message)


def logc(message):
    logger.info(f'|    {message}')


def error(message):
    logger.error(message)


def enter():
    logger.enter()


def end():
    logger.end()
