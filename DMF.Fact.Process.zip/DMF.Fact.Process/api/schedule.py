import schedule
import json
from shutil import rmtree
import api.time as time
import api.http as http
import api.zip as zip
import api.path as path
import api.move as move
import api.data.facts as facts
import api.mongo.db as db
import api.logger as api_logger

log = api_logger.log
logc = api_logger.logc
job_id = api_logger.job_id
error = api_logger.error
end = api_logger.end


SUBMISSIONS_SECTION = "SUBMISSIONS"
FACTS_SECTION = "FACTS"


def run_or_exit(max_wait_time_between_attempts):
    try:
        log('Running or exiting')
        if len(schedule.get_jobs()) > 0:
            logc('running pending tasks')
            schedule.run_pending()
            logc('waiting for next task run attempt')
            time.sleep(max_wait_time_between_attempts)
        else:
            logc('Exiting')
            end()
            exit()
    except Exception as ex:
        error(ex)
        end()
        exit(-1)


def get_minute_job(minutes):
    return schedule.every(minutes).minutes


def get_history_collection_name(collection_name):
    return f'{collection_name}_historic'


def step1_file_download(url, file_path, max_attempts, max_wait_between_attempts, headers):
    try:
        log('Step 1: File Download')
        local_file = http.download_file(
            url, file_path, max_attempts, max_wait_between_attempts, headers)
        logc(local_file)
        return local_file
    except Exception as ex:
        error(ex)
        raise Exception(ex) from None


def step2_attempt_file_unzip(local_file):
    try:
        log('Step 2: Attempting to unzip file')
        dir = zip.try_unzip(local_file)
        logc(f'result: {dir}')
        return dir
    except Exception as ex:
        error(ex)
        raise Exception(ex) from None


def step2_1_archive_zip_file(local_file, archive_path):
    try:
        logc(f'Step 2.1: Moving {local_file} to {archive_path}')
        move.move_file(local_file, archive_path)
    except Exception as ex:
        error(ex)
        raise Exception(ex) from None


def step2_2_1_setup_indexes(run_section, collection, historic_collection, collection_name, historic_collection_name):
    db.index(collection, [('cik', db.DESCENDING)],
             f'{collection_name}_cik_index')

    if run_section == FACTS_SECTION:
        db.index(collection, [('entityName', db.TEXT)],
                 f'{collection_name}_entityName_textindex')
        db.index(collection, [('tickers', db.DESCENDING), ('exchanges', db.DESCENDING)],
                 f'{collection_name}_tickers_exchanges_index')

    if run_section == SUBMISSIONS_SECTION:
        db.index(collection, [('name', db.TEXT)],
                 f'{collection_name}_name_textindex')
        db.index(historic_collection,
                 [('cik', db.DESCENDING), ('file_number', db.ASCENDING)], f'{historic_collection_name}_cik_file_number_index')


def substring_from_filename(file_name, start_index, end_count, char):
    padded_str = file_name[start_index:end_count]
    str = padded_str.lstrip(char)
    return str


def pull_cik_from_filename(file):
    cik = substring_from_filename(file, 3, 13, '0')
    return cik


def pull_file_number_from_filename(file):
    file_number = substring_from_filename(file, 26, 29, '0')
    return file_number


def step2_2_2_1_perform_upsert(filter_map, jdoc, collection):
    requests = facts.get_upsert_requests(
        filter_map, [jdoc]
    )
    db.bulk_write(collection, requests)


def step2_2_2_upsert_docs(dir, files, collection, historic_collection):
    try:
        for file_name in files:
            file = path.os.path.join(dir, file_name)
            with open(file) as f:
                json_str = f.read()
                jdoc = json.loads(json_str)
            try:
                empty_obj_index = json_str.find("{}")
                if empty_obj_index == -1 or empty_obj_index > 0:  # skip empty documents
                    jdoc['dmf_job_id'] = job_id()
                    # ensure json has a cik
                    if "cik" not in jdoc:
                        cik = pull_cik_from_filename(file_name)
                        jdoc['cik'] = cik
                    if file.find("submission") >= 0:
                        # upsert cik#-submissions-#.json documents
                        num = pull_file_number_from_filename(file_name)
                        jdoc['file_number'] = num
                        step2_2_2_1_perform_upsert(
                            ['cik', 'file_number'], jdoc, historic_collection)
                    else:
                        # upsert normal documents
                        step2_2_2_1_perform_upsert(['cik'], jdoc, collection)
                # remove processed document from file system
                path.pathlib.Path(file).unlink(missing_ok=True)
            except Exception as ex:
                error(ex)
    except Exception as ex:
        error(ex)
        raise Exception(ex) from None


def step2_2_0_send_to_db(run_section, dir, db_name, collection_name):
    try:
        collection = db.collection(db_name, collection_name)
        historic_collection_name = get_history_collection_name(collection_name)

        if run_section == SUBMISSIONS_SECTION:
            historic_collection = db.collection(
                db_name, historic_collection_name)
        else:
            historic_collection = None

        step2_2_1_setup_indexes(
            run_section, collection, historic_collection, collection_name, historic_collection_name)

        files = path.get_files(dir, '.json')
        iteration = 0
        while files.__len__() > 0:
            iteration = iteration + 1
            log(f'Initiating upsert iteration {iteration}')
            step2_2_2_upsert_docs(dir, files, collection, historic_collection)
            files = path.get_files(dir, '.json')

    except Exception as ex:
        error(ex)


def task(submission_file_path, fact_file_path, headers, model):
    try:
        max_attempts = model.max_attempts
        max_wait_between_attempts = model.max_wait_between_attempts

        log('Performing steps')

        submissions_local_file = step1_file_download(
            model.submission_url, submission_file_path, max_attempts, max_wait_between_attempts, headers)
        facts_local_file = step1_file_download(
            model.fact_url, fact_file_path, max_attempts, max_wait_between_attempts, headers)

        submissions_dir = step2_attempt_file_unzip(submissions_local_file)
        facts_dir = step2_attempt_file_unzip(facts_local_file)

        if submissions_dir:
            step2_1_archive_zip_file(
                submissions_local_file, model.submission_archive_path)

        if facts_dir:
            step2_1_archive_zip_file(facts_local_file, model.fact_archive_path)

        if submissions_dir:
            step2_2_0_send_to_db(SUBMISSIONS_SECTION, submissions_dir,
                                 model.target_db, model.submission_target_collection)

        if facts_dir:
            step2_2_0_send_to_db(FACTS_SECTION, facts_dir,
                                 model.target_db, model.fact_target_collection)

        path.os.system(f'rmdir /s/q "{submissions_dir}" > nul')
        path.os.system(f'rmdir /s/q "{facts_dir}" > nul')
    except Exception as ex:
        error(ex)
        raise Exception(ex) from None

    return schedule.CancelJob


def schedule_task(job, submission_file_path, fact_file_path, headers, model):
    log(f'Scheduling task')
    job.do(
        task,
        submission_file_path,
        fact_file_path,
        headers,
        model
    )
