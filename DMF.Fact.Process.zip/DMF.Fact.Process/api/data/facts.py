import api.mongo.db as db


def get_upsert_requests(filter_doc_map, docs):
    """
    get_upsert_requests_ex(filter_doc_map=['cik', 'file_number'], docs=[{cik:'33333', file_number: '1'}])
    """
    requests = []
    for doc in docs:
        filter = {}
        for item in filter_doc_map:
            filter[item] = doc[item]
        upsert = db.upsert(filter, doc)
        requests.append(upsert)

    return requests
