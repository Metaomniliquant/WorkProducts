from api.config import app as config


class ScheduleModel:
    def __init__(self) -> None:
        self.fact_url = config.get('fact_url')
        self.fact_out_file = config.get('fact_out_file')
        self.fact_archive_path = config.get('fact_archive_path')
        self.fact_target_collection = config.get('fact_target_collection')
        self.submission_url = config.get('submission_url')
        self.submission_out_file = config.get('submission_out_file')
        self.submission_archive_path = config.get('submission_archive_path')
        self.submission_target_collection = config.get(
            'submission_target_collection')
        self.target_db = config.get('target_db')
        self.minutes = int(config.get('minutes'))
        self.connection_string = config.get('connection_string')
        self.max_attempts = int(config.get('max_attempts'))
        self.max_wait_between_attempts = int(config.get(
            'max_wait_between_attempts'))
        self.expected_extension = config.get('expected_extension')
        self.user_agent_first_name = config.get('user_agent_first_name')
        self.user_agent_last_name = config.get('user_agent_last_name')
        self.user_agent_email = config.get('user_agent_email')
