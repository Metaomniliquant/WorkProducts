import time


def sleep(secs):
    time.sleep(secs)


def time_to_string():
    result = time.strftime('%c')
    return result


def date_time_file_name():
    result = time.strftime('%Y_%m_%d_%I_%M_%S_%p')
    return result
