from pymongo import ReplaceOne, ASCENDING, DESCENDING, TEXT
import api.mongo.dbclient as dbclient


def get(name):
    client = dbclient.get_client()
    return client[name]


def collection(db_name, collection_name):
    return get(db_name)[collection_name]


def index(collection, index, name):
    collection.create_index(index, name=name)


def upsert(filter, replacement):
    # ReplaceOne, upsert=True https://pymongo.readthedocs.io/en/stable/api/pymongo/operations.html#pymongo.operations.ReplaceOne
    return ReplaceOne(filter, replacement, upsert=True)


def bulk_write(collection, requests):
    # bulk_write https://pymongo.readthedocs.io/en/stable/api/pymongo/collection.html#pymongo.collection.Collection.bulk_write
    result = collection.bulk_write(requests)
    return result
