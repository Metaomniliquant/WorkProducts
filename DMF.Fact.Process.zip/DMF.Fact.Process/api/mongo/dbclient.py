from pymongo import MongoClient
from api.config import app as config


def get_client():
    connection_string = config.get('connection_string')
    client = MongoClient(connection_string)
    return client
