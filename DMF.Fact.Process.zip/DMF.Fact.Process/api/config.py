import configparser


APP_SECTION = 'APP'
DEBUG_SECTION = 'DEBUG'
RUN_SECTION_KEY = 'run_section'
APP_CONFIG_FILE_NAME = 'app.ini'


class Config:
    def __init__(self, config_file) -> None:
        self.config = configparser.ConfigParser()
        self.config.read(config_file)
        self.app_config = self.config[APP_SECTION]
        self.run_section = self.app_config[RUN_SECTION_KEY]
        self.section_config = self.config[self.run_section]

    def get(self, key):
        return self.section_config[key]

    def is_debug(self):
        return self.run_section == DEBUG_SECTION


app = Config(APP_CONFIG_FILE_NAME)
