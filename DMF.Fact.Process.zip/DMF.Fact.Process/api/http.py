import time
from urllib.parse import urlparse
import requests
import api.logger as api_logger

log = api_logger.log
logc = api_logger.logc
error = api_logger.error


def get_public_ip():
    endpoint = 'https://api.ipify.org/?format=json'
    with requests.get(endpoint) as response:
        if response.status_code != 200:
            return 'Status: ', response.status_code, 'Problem with the request.'

        data = response.json()
        ip = data['ip']
        return ip


def download_file(url, file_path, max_attempts, max_wait_between_attempts, headers):
    log(f'Preparing to download {url} to {file_path}')
    logc(f'max attempts {max_attempts}')
    logc(f'max wait between attempts {max_wait_between_attempts}')
    logc(f'headers {headers}')

    url = add_scheme(url, 'http')
    for attempt in range(1, max_attempts+1):
        try:
            if attempt > 1:
                time.sleep(max_wait_between_attempts)
            logc(f'attempting download #{attempt}')
            return attempt_file_download(url, file_path, headers)
        except Exception as ex:
            error(f'attempt #{attempt} failed with error: {ex}')
    return ''


def attempt_file_download(url, file_path, headers):
    try:
        log(f'Attempting to download {url} to {file_path}')
        if not headers:
            headers = None
        logc(f'headers {headers}')
        with requests.get(url, headers=headers) as response:
            response.raise_for_status()
            with open(file_path, 'wb') as out_file:
                out_file.write(response.content)
            logc('download finished successfully')
        return file_path
    except Exception as ex:
        error(f'attempt failed with error: {ex}')
        raise Exception(ex) from None


def add_scheme(url, scheme):
    log(f'Adding {scheme} scheme if applicable')
    url_sections = urlparse(url)
    if not url_sections.scheme:
        logc('the given url is missing a scheme. Adding http scheme.')
        url = f'{scheme}://{url}'
        logc(f'new url: {url}')
    return url
