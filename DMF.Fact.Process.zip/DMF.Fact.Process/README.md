# DMF.Fact.Process

The DMF Fact process retrieves and extracts company facts

Delete left-over files while bypassing recycle bin:

cd /d Z:\SECDataTest
del /f/q/s \*.\* > nul
