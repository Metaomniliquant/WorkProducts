import { Model, Schema as MongooseSchema } from 'mongoose';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { FactLog, FactLogsDocument } from './fact-log.schema';
import { FactLogPagingSortingInput } from './fact-log.paging';

@Injectable()
export class FactLogsService {
  constructor(@InjectModel(FactLog.name) private factLogModel: Model<FactLogsDocument>) {}

  async getLogs() {
    return this.factLogModel.find();
  }

  async getLog(id: MongooseSchema.Types.ObjectId) {
    return this.factLogModel.findById(id);
  }

  async getCount() {
    return this.factLogModel.countDocuments();
  }

  async pageLog(pageArgs: FactLogPagingSortingInput) {
    return this.factLogModel.find(null, null, {
      limit: pageArgs.take,
      skip: pageArgs.skip,
      sort: pageArgs.sort
    });
  }

  async getLogsByJobId(job_id: MongooseSchema.Types.ObjectId) {
    return this.factLogModel.find({job_id});
  }
}