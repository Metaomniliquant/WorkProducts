import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { ObjectType, Field } from '@nestjs/graphql';
import { GraphQLObjectID } from '../graphql/graphql-object-id';
import { FactJob } from '../fact-job/fact-job.schema';

export type FactLogsDocument = FactLog & Document;

@Schema({ autoIndex: false, autoCreate: false, collection: 'fact_logs' })
@ObjectType({ description: "The type representing an entry in the fact_logs collection." })
export class FactLog {
  @Prop()
  @Field(() => GraphQLObjectID)
  _id: MongooseSchema.Types.ObjectId;

  @Prop()
  @Field(() => GraphQLObjectID)
  job_id: MongooseSchema.Types.ObjectId;

  @Prop()
  @Field(() => [FactJob], { nullable: 'itemsAndList'})
  job?: [FactJob] | null;

  @Prop()
  @Field()
  time: string;

  @Prop()
  @Field()
  type: number;

  @Prop()
  @Field()
  message: string;
}

export const FactLogsSchema = SchemaFactory.createForClass(FactLog);