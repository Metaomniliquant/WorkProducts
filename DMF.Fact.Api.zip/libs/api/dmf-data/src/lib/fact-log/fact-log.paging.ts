import { Field, InputType } from '@nestjs/graphql';
import { SortOrder } from 'mongoose';
import { Sort, SortInput } from '../pagination/sort.type';
import { PageArgs } from '../pagination/page.args';

@InputType()
export class FactLogSortInput extends SortInput<FactLogSortInput> {
    @Field(() => Sort, { nullable: true })
    type?: SortOrder | null;
    @Field(() => Sort, { nullable: true })
    time?: SortOrder | null;
    @Field(() => Sort, { nullable: true })
    message?: SortOrder | null;
}

@InputType()
export class FactLogPagingSortingInput extends PageArgs {
    @Field(() => FactLogSortInput, { nullable: true})
    sort?: FactLogSortInput | null;
}