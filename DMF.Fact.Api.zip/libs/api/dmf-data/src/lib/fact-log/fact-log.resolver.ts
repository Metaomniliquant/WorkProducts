import { Resolver, Query, Args, ResolveField, Parent } from '@nestjs/graphql'
import { Schema as MongooseSchema } from 'mongoose'
import { FactLog } from './fact-log.schema'
import { FactLogsService } from './fact-log.service'
import { FactLogPagingSortingInput } from './fact-log.paging';
import { FactJob } from '../fact-job/fact-job.schema';
import { FactJobsService } from '../fact-job/fact-job.service';

@Resolver(() => FactLog)
export class FactLogsResolver {
  constructor(
    private factLogsService: FactLogsService,
    private factJobsService: FactJobsService
  ) {}

  @Query(() => [FactLog], { name: 'allLogs', description: "Retrieves the fact logs collection" })
  async getLogs() {
    return this.factLogsService.getLogs();
  }

  @Query(() => FactLog, { name: 'log', description: "Retrieves a single fact log by object id", nullable: true })
  async getLog(@Args('_id', { type: () => String }) _id: MongooseSchema.Types.ObjectId) {
    return this.factLogsService.getLog(_id)
  }

  @Query(() => Number, { name: 'logCount'})
  async getCount() {
    return this.factLogsService.getCount();
  }

  @Query(() => [FactLog], { name: 'logsPage'})
  async getPaged(@Args('paging') pageArgs: FactLogPagingSortingInput) {
    return this.factLogsService.pageLog(pageArgs);
  }

  @ResolveField('job', () => FactJob)
  async getLogJob(@Parent() log: FactLog, @Args("populate") populate: boolean) {
    if (populate)
      return this.factJobsService.getJob(log.job_id);
    return log.job_id;
  }
}