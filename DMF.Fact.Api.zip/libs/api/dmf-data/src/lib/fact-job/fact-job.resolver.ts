import { Resolver, Query, Args, ResolveField, Parent } from '@nestjs/graphql'
import { FactJob } from './fact-job.schema'
import { FactJobsService } from './fact-job.service'
import { Schema as MongooseSchema } from 'mongoose'
import { FactLogsService } from '../fact-log/fact-log.service'
import { FactLog } from '../fact-log/fact-log.schema'
import { FactJobPagingSortingInput } from './fact-job.paging'

@Resolver(() => FactJob)
export class FactJobsResolver {
  constructor(
    private factJobsService: FactJobsService,
    private factLogsService: FactLogsService
  ) {}

  @Query(() => [FactJob], { name: 'allJobs', description: "Retrieves the fact jobs collection" })
  async getJobs() {
    return this.factJobsService.getJobs()
  }

  @Query(() => FactJob, { name: 'job', description: "Retrieves a single fact job by object id", nullable: true })
  async getJob(@Args('_id', { type: () => String }) _id: MongooseSchema.Types.ObjectId) {
    return this.factJobsService.getJob(_id)
  }

  @Query(() => Number, { name: 'jobCount'})
  async getCount() {
    return this.factJobsService.getCount();
  }

  @Query(() => [FactJob], { name: 'jobsPage'})
  async getPaged(@Args('paging') pageArgs: FactJobPagingSortingInput) {
    return this.factJobsService.pageJobs(pageArgs);
  }

  @ResolveField('logs', () => [FactLog], { description: "The logs associated with a job" })
  async getJobLogs(@Parent() job: FactJob, @Args('populate') populate: boolean) {
    if (populate)
      return this.factLogsService.getLogsByJobId(job._id);
    return job._id;
  }
}