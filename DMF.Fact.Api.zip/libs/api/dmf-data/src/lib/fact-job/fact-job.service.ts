import { Model, Schema as MongooseSchema } from 'mongoose';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { FactJob, FactJobsDocument } from './fact-job.schema';
import { FactJobPagingSortingInput } from './fact-job.paging';

@Injectable()
export class FactJobsService {
  constructor(@InjectModel(FactJob.name) private factJobModel: Model<FactJobsDocument>) {}

  async getJobs() {
    return this.factJobModel.find();
  }

  async getJob(id: MongooseSchema.Types.ObjectId) {
    return this.factJobModel.findById(id);
  }

  async getCount() {
    return this.factJobModel.countDocuments();
  }

  async pageJobs(pageArgs: FactJobPagingSortingInput) {
    return this.factJobModel.find(null, null, {
      limit: pageArgs.take,
      skip: pageArgs.skip,
      sort: pageArgs.sort
    });
  }
}