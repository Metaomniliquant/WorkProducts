import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { ObjectType, Field } from '@nestjs/graphql';
import { GraphQLObjectID } from '../graphql/graphql-object-id';
import { FactLog } from '../fact-log/fact-log.schema';

export type FactJobsDocument = FactJob & Document;

@Schema({ autoIndex: false, autoCreate: false, collection: 'fact_jobs' })
@ObjectType({ description: "The type representing an entry in the fact_jobs collection." })
export class FactJob {
  @Prop()
  @Field(() => GraphQLObjectID)
  _id: MongooseSchema.Types.ObjectId;

  @Prop()
  @Field(() => [FactLog], { nullable: 'itemsAndList' })
  logs?: FactLog[] | null;

  @Prop()
  @Field()
  start_date: string;

  @Prop()
  @Field({ nullable: true })
  end_date?: string | null;
}

export const FactJobsSchema = SchemaFactory.createForClass(FactJob);