import { Field, InputType } from '@nestjs/graphql';
import { SortInput, Sort } from '../pagination/sort.type';
import { PageArgs } from '../pagination/page.args';
import { SortOrder } from 'mongoose';

@InputType()
export class FactJobSortInput extends SortInput<FactJobSortInput> {
    @Field(() => Sort, { nullable: true })
    start_date?: SortOrder | null;
    @Field(() => Sort, { nullable: true })
    end_date?: SortOrder | null;
}

@InputType()
export class FactJobPagingSortingInput extends PageArgs {
    @Field(() => FactJobSortInput, {nullable: true})
    sort?: FactJobSortInput | null;
}