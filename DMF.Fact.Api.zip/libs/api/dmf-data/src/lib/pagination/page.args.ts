import { InputType, Field, Int } from "@nestjs/graphql";


@InputType({ isAbstract: true })
export abstract class PageArgs {
    @Field(() => Int)
    skip = 0

    @Field(() => Int)
    take = 25
}
