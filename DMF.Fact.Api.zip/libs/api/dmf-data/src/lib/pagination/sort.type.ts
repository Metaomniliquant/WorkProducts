import { registerEnumType } from "@nestjs/graphql"
import { SortOrder } from "mongoose";

export type EnforceSortInputType<T> = {
    [K in keyof T] : T[K] extends SortOrder ? SortOrder : SortOrder;
}

export class SortInput<T extends EnforceSortInputType<T>> {
    [K: string]: SortOrder;
}

export enum Sort {
    asc = "asc",
    desc = "desc"
}

registerEnumType(Sort, { name: 'sort'})
