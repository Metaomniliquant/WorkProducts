import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { FactLog, FactLogsSchema } from './fact-log/fact-log.schema';
import { FactJob, FactJobsSchema } from './fact-job/fact-job.schema';
import { FactLogsResolver } from './fact-log/fact-log.resolver';
import { FactLogsService } from './fact-log/fact-log.service';
import { FactJobsResolver } from './fact-job/fact-job.resolver';
import { FactJobsService } from './fact-job/fact-job.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: FactLog.name, schema: FactLogsSchema },
      { name: FactJob.name, schema: FactJobsSchema }
    ])
  ],
  controllers: [],
  providers: [
    FactLogsResolver,
    FactLogsService,
    FactJobsResolver,
    FactJobsService
  ],
  exports: [],
})
export class ApiDmfDataModule {}
