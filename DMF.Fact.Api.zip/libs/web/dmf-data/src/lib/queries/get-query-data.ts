import { DocumentNode, OperationVariables, TypedDocumentNode, useQuery } from "@apollo/client";

type GetQueryDataScheme<TReturnData, TProps> = DocumentNode | TypedDocumentNode<TReturnData, TProps>;
export type GetQueryDataProps = OperationVariables | undefined;

export type GetQueryDataFunc<TReturnData> = (
        schema: GetQueryDataScheme<TReturnData, GetQueryDataProps>,
        props: GetQueryDataProps) => TReturnData;

export function GetQueryData<TReturnData> (
    schema: GetQueryDataScheme<TReturnData, GetQueryDataProps>,
    props: GetQueryDataProps) {
        const {data} = useQuery<TReturnData>(schema, {
            variables: props
        });
        return data;
    }

