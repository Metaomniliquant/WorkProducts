import { JobsPage } from "../models/dmf-data.models";
import { SCHEMA_GET_JOBS_PAGE_WITHOUT_LOGS, SCHEMA_GET_JOBS_PAGE_WITH_LOGS } from "../schemas/fact-job.schema";
import { GetQueryData, GetQueryDataFunc, GetQueryDataProps } from "./get-query-data";

export type GetFactJobsQueryData = {
    jobCount: number;
    jobsPage: JobsPage[];
} | undefined;

export const GetFactJobsQuery: GetQueryDataFunc<GetFactJobsQueryData>
    = GetQueryData<GetFactJobsQueryData>;

export function GetFactJobsWithLogsQuery(props: GetQueryDataProps) {
    return GetQueryData<GetFactJobsQueryData>(SCHEMA_GET_JOBS_PAGE_WITH_LOGS, props);
}

export function GetFactJobsWithoutLogsQuery(props: GetQueryDataProps) {
    return GetQueryData<GetFactJobsQueryData>(SCHEMA_GET_JOBS_PAGE_WITHOUT_LOGS, props);
}