import { LogsPage } from "../models/dmf-data.models";
import { SCHEMA_GET_LOGS_PAGE_WITHOUT_JOBS, SCHEMA_GET_LOGS_PAGE_WITH_JOBS } from "../schemas/fact-log.schema";
import { GetQueryData, GetQueryDataFunc, GetQueryDataProps } from "./get-query-data";

export type GetFactLogsQueryData = {
    logCount: number;
    logsPage: LogsPage[];
} | undefined;

export const GetFactLogsQuery: GetQueryDataFunc<GetFactLogsQueryData>
    = GetQueryData<GetFactLogsQueryData>;

export function GetFactLogsWithJobsQuery(props: GetQueryDataProps) {
    return GetQueryData<GetFactLogsQueryData>(SCHEMA_GET_LOGS_PAGE_WITH_JOBS, props);
}

export function GetFactLogsWithoutJobsQuery(props: GetQueryDataProps) {
    return GetQueryData<GetFactLogsQueryData>(SCHEMA_GET_LOGS_PAGE_WITHOUT_JOBS, props);
}