import styles from './web-dmf-data.module.css';

/* eslint-disable-next-line */
export interface WebDmfDataProps {}

export function WebDmfData(props: WebDmfDataProps) {
  return (
    <div className={styles['container']}>
      <h1>Welcome to WebDmfData!</h1>
    </div>
  );
}

export default WebDmfData;
