
export enum Sort {
    asc = "asc",
    desc = "desc"
}

type PagingSortingInput<T> = {
    skip: number;
    take: number;
    sort?: T | null;
}

export type JobsPage = {
    //[key: string]: string | LogsPage[] | null | undefined;
    __typename: string;
    _id: string;
    start_date: string;
    end_date: string;
    logs?: LogsPage[] | null;
}

export type JobsSortInput = {
    start_date?: Sort | null;
    end_date?: Sort | null;
}

export type JobsPagingSortingInput = PagingSortingInput<JobsSortInput>;

export type LogsPageFieldType = string | number | JobsPage | null | undefined;

export type LogsPage = {
    //[key: string]: LogsPageFieldType;
    __typename: string;
    _id: string;
    job_id: string;
    type: number;
    time: string;
    message: string;
    job?: JobsPage | null;
}

export type LogsSortInput = {
    message?: Sort | null;
    time?: Sort | null;
    type?: Sort | null;
}

export type LogsPagingSortingInput = PagingSortingInput<LogsSortInput>;