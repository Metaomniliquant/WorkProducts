import { gql } from '@apollo/client';

export const SCHEMA_GET_LOGS_PAGE_WITH_JOBS = gql`
    query GetLogsPageWithJobs($paging: FactLogPagingSortingInput!) {
        logCount,
        logsPage(paging: $paging) {
            __typename,
            _id,
            job_id,
            type,
            time,
            message,
            job(populate:true) {
                __typename,
                _id,
                start_date,
                end_date
            }
        }
    }
`

export const SCHEMA_GET_LOGS_PAGE_WITHOUT_JOBS = gql`
    query GetLogsPageWithoutJobs($paging: FactLogPagingSortingInput!) {
        logCount,
        logsPage(paging: $paging) {
            __typename,
            _id,
            job_id,
            type,
            time,
            message
        }
    }
`
