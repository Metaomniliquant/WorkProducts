import { gql } from '@apollo/client';

export const SCHEMA_GET_JOBS_PAGE_WITH_LOGS = gql`
    query GetJobsPageWithLogs($paging: FactJobPagingSortingInput!) {
        jobCount,
        jobsPage(paging: $paging) {
            __typename,
            _id,
            start_date,
            end_date,
            logs(populate:true) {
                __typename,
                _id,
                job_id,
                time,
                type,
                message
            }
        }
    }
`

export const SCHEMA_GET_JOBS_PAGE_WITHOUT_LOGS = gql`
    query GetJobsPageWithoutLogs($paging: FactJobPagingSortingInput!) {
        jobCount,
        jobsPage(paging: $paging) {
            __typename,
            _id,
            start_date,
            end_date
        }
    }
`
