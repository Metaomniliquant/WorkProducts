import { render } from '@testing-library/react';

import WebDmfData from './web-dmf-data';

describe('WebDmfData', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<WebDmfData />);
    expect(baseElement).toBeTruthy();
  });
});
