import { Dispatch, SetStateAction, createContext } from 'react';
import { GetFactJobsQueryData, GetFactLogsQueryData } from '../queries';
import { JobsPagingSortingInput, LogsPagingSortingInput } from '../models/dmf-data.models';

// Table Paging:

export type FactJobsPagingSortingContextType = {
    paging: JobsPagingSortingInput;
    setPaging: Dispatch<SetStateAction<JobsPagingSortingInput>>;
}

export const FactJobPagingSortingContext = createContext({} as FactJobsPagingSortingContextType);

export type FactLogsPagingSortingContextType = {
    paging: LogsPagingSortingInput;
    setPaging: Dispatch<SetStateAction<LogsPagingSortingInput>>;
}

export const FactLogPagingSortingContext = createContext({} as FactLogsPagingSortingContextType);

// Data:

export type FactJobsDataContextType = {
    data: GetFactJobsQueryData;
    setData?: Dispatch<SetStateAction<GetFactJobsQueryData>>;
}
export const FactJobsDataContext = createContext({} as FactJobsDataContextType);

export type FactLogsDataContextType = {
    data: GetFactLogsQueryData;
    setData?: Dispatch<SetStateAction<GetFactLogsQueryData>>;
}
export const FactLogsDataContext = createContext({} as FactLogsDataContextType);