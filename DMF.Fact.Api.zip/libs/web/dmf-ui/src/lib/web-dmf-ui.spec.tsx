import { render } from '@testing-library/react';

import WebDmfUi from './web-dmf-ui';

describe('WebDmfUi', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<WebDmfUi />);
    expect(baseElement).toBeTruthy();
  });
});
