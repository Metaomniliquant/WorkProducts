import { Route, Link } from 'react-router-dom';

import styles from './web-dmf-ui.module.css';

/* eslint-disable-next-line */
export interface WebDmfUiProps {}

export function WebDmfUi(props: WebDmfUiProps) {
  return (
    <div className={styles['container']}>
      <h1>Welcome to WebDmfUi!</h1>

      <ul>
        <li>
          <Link to="/">web-dmf-ui root</Link>
        </li>
      </ul>
      <Route path="/" element={<div>This is the web-dmf-ui root route.</div>} />
    </div>
  );
}

export default WebDmfUi;
