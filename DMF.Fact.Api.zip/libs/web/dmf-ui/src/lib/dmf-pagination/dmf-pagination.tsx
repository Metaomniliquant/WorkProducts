import styles from './dmf-pagination.module.css';


import { ChangeEvent, cloneElement, FunctionComponentElement, useState } from 'react';
import { GetQueryDataProps } from '@dmf-web/dmf-data';
import { PagingInput } from './dmf-paging.model';

/* eslint-disable-next-line */
export interface DmfPaginationProps {
  count: number;
  render: FunctionComponentElement<PagingInput>
}

export function DmfPagination(props: DmfPaginationProps) {
  const { count, render } = props;
  const [step, setStep] = useState(0);
  const [take, setTake] = useState(10);

  const renderWithProps = cloneElement(render, {
    skip: step * take,
    take
  });

  const renderTakeOptions = (max: number, steps: number) => {
    const options = new Array(max).fill(0).map((num, index) => {
      const itemNumber = index+1;
      const next = step * itemNumber;
      return (<option value={next} key={index}>{next}</option>)
    });

    return options;
  };

  const renderTakes = (take: number) => {
    <select
      name="Pages per row"
      id="take"
      value={take}
      onChange={(e: ChangeEvent<HTMLSelectElement>) => {
        const newTake = +e.target.value;
        setTake(newTake);
        setStep(0);
      }}
    >
      {renderTakeOptions(10, 10)}
    </select>
  }

  const renderPrevButton = (step: number) => {
    return (
      <button
        type="button"
        disabled={step===0}
        onClick={() => setStep((prevstep) => prevstep - 1)}
      >
        {'<'}
      </button>
    )
  };

  const renderNextButton = (step: number, take: number, count: number) => {
    return (
      <button
        type="button"
        disabled={(step + 1) * take > count}
        onClick={() => setStep((prevstep) => prevstep + 1)}
      >
        {'>'}
      </button>
    )
  };

  return (
    <>
      {renderWithProps}
      {renderTakes(take)}
      {renderPrevButton(step)}
      {renderNextButton(step, take, count)}
    </>
  );
}

export default DmfPagination;
