
export interface PagingInput {
    skip: number;
    take: number;
}