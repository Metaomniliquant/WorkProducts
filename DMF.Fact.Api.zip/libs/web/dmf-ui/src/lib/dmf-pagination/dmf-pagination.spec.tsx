import { render } from '@testing-library/react';

import DmfPagination from './dmf-pagination';

describe('DmfPagination', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<DmfPagination />);
    expect(baseElement).toBeTruthy();
  });
});
