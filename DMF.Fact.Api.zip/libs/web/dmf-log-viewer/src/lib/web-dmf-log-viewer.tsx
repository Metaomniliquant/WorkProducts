import { Route, Routes } from 'react-router-dom';

import styles from './web-dmf-log-viewer.module.css';
import DmfFactJobs from './dmf-fact-jobs/dmf-fact-jobs';

/* eslint-disable-next-line */
export interface WebDmfLogViewerProps {}

export function WebDmfLogViewer(props: WebDmfLogViewerProps) {
  return (
    <div className={styles['container']}>
      <h1>Welcome to WebDmfLogViewer!</h1>

      <Routes>
        <Route
          path="/"
          element={<DmfFactJobs withLogs={true}></DmfFactJobs>}
        />
      </Routes>
    </div>
  );
}

export default WebDmfLogViewer;
