import { render } from '@testing-library/react';

import DmfFactJobs from './dmf-fact-jobs';

describe('DmfFactJobs', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<DmfFactJobs />);
    expect(baseElement).toBeTruthy();
  });
});
