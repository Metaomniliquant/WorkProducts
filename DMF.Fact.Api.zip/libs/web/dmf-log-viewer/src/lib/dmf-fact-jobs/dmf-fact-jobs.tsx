import { FactJobPagingSortingContext, FactJobsDataContext, GetFactJobsQueryData, GetFactJobsWithLogsQuery, GetFactJobsWithoutLogsQuery, JobsPagingSortingInput, Sort } from '@dmf-web/dmf-data';
import { useState } from 'react';
import FactJobList from '../fact-job-list/fact-job-list';
import FactJobPager from '../fact-job-pager/fact-job-pager';

/* eslint-disable-next-line */
export interface DmfFactJobsProps {
  withLogs: boolean;
}

export function DmfFactJobs(props: DmfFactJobsProps) {
  const { withLogs } = props;
  const [paging,setPaging] = useState({
    skip: 0,
    take: 1,
    sort: {
      start_date: Sort.desc
    }
  } as JobsPagingSortingInput);

  const currentData = withLogs ? GetFactJobsWithLogsQuery({paging}) : GetFactJobsWithoutLogsQuery({paging});
  const [, setData] = useState({...currentData} as GetFactJobsQueryData);

  return (
    <FactJobPagingSortingContext.Provider value={{paging, setPaging}}>
      <FactJobsDataContext.Provider value={{data: currentData, setData}}>
        <FactJobList withLogs={withLogs}></FactJobList>
        <FactJobPager></FactJobPager>
      </FactJobsDataContext.Provider>
    </FactJobPagingSortingContext.Provider>
  );
}

export default DmfFactJobs;
