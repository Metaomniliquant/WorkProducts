import { render } from '@testing-library/react';

import FactLog from './fact-log';

describe('FactLog', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<FactLog />);
    expect(baseElement).toBeTruthy();
  });
});
