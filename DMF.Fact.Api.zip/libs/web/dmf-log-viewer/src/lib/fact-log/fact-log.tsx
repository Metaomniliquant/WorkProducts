import { LogsPage } from '@dmf-web/dmf-data';

/* eslint-disable-next-line */
export interface FactLogProps {
  logPage: LogsPage;
}

export function FactLog(props: FactLogProps) {
  const { logPage } = props;
  const { __typename, _id, message, time, type } = logPage;

  const styles = {
    dataLogType: "data-[log-type='1']:bg-green-100 data-[log-type='2']:bg-orange-100 data-[log-type='90']:bg-red-100 data-[log-type='10']:bg-sky-100",
    factLogContainer: "fact-log-container flex items-center"
  };

  return (
    <div className={`${styles.factLogContainer} ${styles.dataLogType}`} data-log-typename={__typename} data-log-type={type}>
        <div className="fact-log-item w-1/5 inline-block">{_id}</div>
        <div className="fact-log-item w-1/5 inline-block">{time}</div>
        <div className="fact-log-item w-3/5 inline-block">{message}</div>
    </div>
  );
}

export default FactLog;
