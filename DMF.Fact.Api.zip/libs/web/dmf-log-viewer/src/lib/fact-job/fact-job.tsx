import { FactLogsDataContext, GetFactLogsQueryData, JobsPage } from '@dmf-web/dmf-data';
import FactLogList from '../fact-log-list/fact-log-list';
import { useState } from 'react';

/* eslint-disable-next-line */
export interface FactJobProps {
  jobPage: JobsPage;
  withLogs: boolean;
}

export function FactJob(props: FactJobProps) {
  const [ data, setData ] = useState({ showLogs: false });
  const { jobPage, withLogs } = props;
  const { __typename, _id, start_date, end_date, logs } = jobPage;

  const renderLogs = (withLogs: boolean) => {
    if (withLogs) {
      const logsData: GetFactLogsQueryData = {
        logCount: logs?.length || 0,
        logsPage: logs || []
      };
      return (
        <FactLogsDataContext.Provider value={{data: logsData}}>
          <FactLogList></FactLogList>
        </FactLogsDataContext.Provider>
      );
    }

    return;
  };

  const renderLogsSection = (withLogs: boolean) => {
    if (withLogs) {
      return (
      <>
        <div className="fact-job-item w-1/4 inline-block text-center">
          <button onClick={() => setData({showLogs: !data.showLogs})} title='Expand to Logs'>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
            </svg>
          </button>
        </div>
        <div className="fact-job-item data-[show-logs='true']:block data-[show-logs='false']:hidden" data-show-logs={data.showLogs}>
          {renderLogs(withLogs)}
        </div>
      </>
      );
    }

    return;
  }

  return (
    <div className="">
      <div className="fact-job-container block" data-job-typename={__typename}>
        <div className="fact-job-item w-1/4 inline-block">{_id}</div>
        <div className="fact-job-item w-1/4 inline-block">{start_date}</div>
        <div className="fact-job-item w-1/4 inline-block">{end_date}</div>
        {renderLogsSection(withLogs)}
      </div>
    </div>
  );
}

export default FactJob;
