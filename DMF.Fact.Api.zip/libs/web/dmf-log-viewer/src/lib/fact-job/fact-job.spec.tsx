import { render } from '@testing-library/react';

import FactJob from './fact-job';

describe('FactJob', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<FactJob />);
    expect(baseElement).toBeTruthy();
  });
});
