import { FactJobPagingSortingContext, FactJobsDataContext } from '@dmf-web/dmf-data';
import { useContext } from 'react';

/* eslint-disable-next-line */
export interface FactJobPagerProps {
}

export function FactJobPager(props: FactJobPagerProps) {
  const { data, } = useContext(FactJobsDataContext);
  const { paging, setPaging } = useContext(FactJobPagingSortingContext);

  const count = data?.jobCount || 0;

  const updateSkip = (skip: number) => {
    setPaging({
      ...paging, skip
    });
  }

  return (
    <div className="fact-job-pager-container">
      <label>Rows per page:</label>
      <select onChange={(e) => {
        const take = +e.currentTarget.value;
        setPaging({
          ...paging, skip: 0, take
        });
      }}>
        <option value={1}>1</option>
        <option value={2}>2</option>
        <option value={3}>3</option>
        <option value={5}>5</option>
      </select>
      <button onClick={() => {
        let skip = paging.skip;
        if (0 <= (skip - paging.take)) {
          skip -= paging.take;
        }
        updateSkip(skip);
      }}>Previous</button>
      <button onClick={() => {
        let skip = paging.skip;
        if (count > (skip + paging.take)) {
          skip += paging.take;
        }
        updateSkip(skip);
      }}>Next</button>
    </div>
  );
}

export default FactJobPager;
