import { render } from '@testing-library/react';

import FactJobPager from './fact-job-pager';

describe('FactJobPager', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<FactJobPager />);
    expect(baseElement).toBeTruthy();
  });
});
