import { useContext } from 'react';
import { FactJobsDataContext } from '@dmf-web/dmf-data';
import FactJob from '../fact-job/fact-job';

/* eslint-disable-next-line */
export interface FactJobListProps {
  withLogs: boolean;
}

export function FactJobList(props: FactJobListProps) {
  const { withLogs } = props;
  const { data } = useContext(FactJobsDataContext);

  const renderJobs = (withLogs: boolean) => {
    return data?.jobsPage?.map((jobPage, index) => {
      return (
        <FactJob key={index} jobPage={jobPage} withLogs={withLogs}></FactJob>
      )
    });
  };

  const renderActionColumn = (withLogs: boolean) => {
    if (withLogs) {
      return (<div className="fact-job-header-item w-1/4 inline-block font-bold text-center">Action</div>);
    }

    return;
  }

  return (
    <div className="fact-job-list-container w-11/12 m-auto">
      <div className="fact-job-container-header block">
        <div className="fact-job-header-item w-1/4 inline-block font-bold">Id</div>
        <div className="fact-job-header-item w-1/4 inline-block font-bold">Start Date</div>
        <div className="fact-job-header-item w-1/4 inline-block font-bold">End Date</div>
        {renderActionColumn(withLogs)}
      </div>
        {renderJobs(withLogs)}
    </div>
  );
}

export default FactJobList;
