import { render } from '@testing-library/react';

import FactJobList from './fact-job-list';

describe('FactJobList', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<FactJobList />);
    expect(baseElement).toBeTruthy();
  });
});
