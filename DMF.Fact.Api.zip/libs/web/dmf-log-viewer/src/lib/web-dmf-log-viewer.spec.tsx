import { render } from '@testing-library/react';

import WebDmfLogViewer from './web-dmf-log-viewer';

describe('WebDmfLogViewer', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<WebDmfLogViewer />);
    expect(baseElement).toBeTruthy();
  });
});
