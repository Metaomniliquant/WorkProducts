import { useContext } from 'react';
import { FactLogsDataContext } from '@dmf-web/dmf-data';
import FactLog from '../fact-log/fact-log';

/* eslint-disable-next-line */
export interface FactLogListProps {}

export function FactLogList(props: FactLogListProps) {
  const { data, } = useContext(FactLogsDataContext);

  const renderLogs = () => {
    return data?.logsPage?.map((logPage, index) => {
      return (
        <FactLog key={index} logPage={logPage}></FactLog>
      )
    });
  }

  return (
    <div className="fact-log-list-container h-[50vh] overflow-x-hidden overflow-y-scroll">
      {renderLogs()}
    </div>
  );
}

export default FactLogList;
