import { render } from '@testing-library/react';

import FactLogList from './fact-log-list';

describe('FactLogList', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<FactLogList />);
    expect(baseElement).toBeTruthy();
  });
});
