export function sharedInterfaces(): string {
  return 'shared-interfaces';
}
