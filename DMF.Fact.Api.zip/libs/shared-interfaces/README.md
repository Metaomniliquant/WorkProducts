# shared-interfaces

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build shared-interfaces` to build the library.
