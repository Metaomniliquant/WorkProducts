// eslint-disable-next-line @typescript-eslint/no-unused-vars
import styles from './app.module.css';

import { Route, Routes, Link } from 'react-router-dom';

import { WebDmfLogViewer } from '@dmf-web/dmf-log-viewer';

export function App() {
  return (
    <>
      <div />
      <br />
      <hr />
      <br />
      <div role="navigation">
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/data-viewer/jobs">Jobs</Link>
          </li>
        </ul>
      </div>
      <Routes>
        <Route path="/data-viewer/jobs" element={<WebDmfLogViewer />} />
      </Routes>
    </>
  );
}

export default App;
